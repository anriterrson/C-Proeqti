﻿using System.Globalization;

// BackendStageOneApp - konsoluri proeqti
// moicavs: kalkulatori, ricxvis gamocnoba

// programis gaShveba
BackendStageOneApp.Run();

// sabazoo abstractuli klasi yvela modulistvis
abstract class KonsolisModuli
{
    // modulis saxeli (gamoCndeba meniuSi)
    public string Saxeli { get; }

    protected KonsolisModuli(string saxeli)
    {
        Saxeli = saxeli;
    }

    // titoeuli moduli axorcielebs Gaushve()-s
    public abstract void Gaushve();
}

// mtavari aplikacia - meniu da navigacia
static class BackendStageOneApp
{
    public static void Run()
    {
        while (true)
        {
            Console.WriteLine("Proeqti");
            Console.WriteLine("1. Kalkulatori");       // kalkulatori
            Console.WriteLine("2. Ricxvis Gamocnoba"); // ricxvis gamocnoba
            Console.WriteLine("0. Gasvla");            // gasvla

            int archevani = InputHelper.WaikitkheInt("Airchie optsia: ", 0, 2);

            // 0 - gasvla programidan
            if (archevani == 0)
            {
                Console.WriteLine("Naxhvamdis!");
                break;
            }

            // archevuli modulis gaShveba
            switch (archevani)
            {
                case 1:
                    new KalkulatorisModuli().Gaushve();
                    break;

                case 2:
                    new RicxvisGamocnobisModuli().Gaushve();
                    break;
            }

            InputHelper.Daachere();
        }
    }
}

// kalkulatoris moduli
class KalkulatorisModuli : KonsolisModuli
{
    // mxardachili operaciebi - masivshi
    private static readonly string[] NebadartmuliOperaciebi = { "+", "-", "*", "/" };

    public KalkulatorisModuli() : base("Kalkulatori") { }

    public override void Gaushve()
    {
        Console.WriteLine("=== Kalkulatori ===");

        // Sesatani ricxvebis wakitxva
        double pirveli = InputHelper.WaikitkheDouble("Pirveli ricxvi: ");
        double meore = InputHelper.WaikitkheDouble("Meore ricxvi: ");

        // operaciis archeva
        Console.Write($"Operacia ({string.Join(", ", NebadartmuliOperaciebi)}): ");
        string operacia = Console.ReadLine() ?? "";

        // Seamowme operacia validuria tu ara
        if (!Array.Exists(NebadartmuliOperaciebi, op => op == operacia))
        {
            Console.WriteLine("Aravalidi operacia.");
            return;
        }

        double shedegi;

        // gamotvla archevuli operaciis mixedvit
        switch (operacia)
        {
            case "+": shedegi = pirveli + meore; break;
            case "-": shedegi = pirveli - meore; break;
            case "*": shedegi = pirveli * meore; break;
            case "/":
                // nulze gayofis Shemowmeba
                if (meore == 0)
                {
                    Console.WriteLine("Nulze gayofa SeuZlebelia.");
                    return;
                }
                shedegi = pirveli / meore;
                break;
            default:
                Console.WriteLine("Aravalidi operacia.");
                return;
        }

        // shedegis gamoTana
        Console.WriteLine($"Shedegi: {shedegi}");
    }
}

// ricxvis gamocnobis moduli
class RicxvisGamocnobisModuli : KonsolisModuli
{
    // ministnebis shablonebi - masivshi
    private static readonly string[] MinistnebisMasivi =
    {
        "Dzaan Shorstaa",    // 5+ dashoreba
        "Shorstaa",          // 4 dashoreba
        "Cota Axloaa",       // 3 dashoreba
        "Axloaa",            // 2 dashoreba
        "Dzaan Axloaa"       // 1 dashoreba
    };

    public RicxvisGamocnobisModuli() : base("Ricxvis Gamocnoba") { }

    public override void Gaushve()
    {
        Console.WriteLine("=== Ricxvis Gamocnoba ===");

        // saidumlo ricxvi 1-dan 100-mde
        int saidumloRicxvi = Random.Shared.Next(1, 101);
        int mcdelobaTa = 0;

        // masivi bolo 5 gamocnobis Sesanaxad
        int[] boloGamocnobebi = new int[5];
        int gamocnobaThvla = 0;

        while (true)
        {
            int gamocnoba = InputHelper.WaikitkheInt("Gamoicani ricxvi (1-100): ", 1, 100);
            mcdelobaTa++;

            // bolo gamocnobebis Senaxva (bolo 5)
            boloGamocnobebi[gamocnobaThvla % 5] = gamocnoba;
            gamocnobaThvla++;

            // swori gamocnoba
            if (gamocnoba == saidumloRicxvi)
            {
                Console.WriteLine($"Sworia! Mcdelobata raodenoba: {mcdelobaTa}");

                // bolo gamocnobebis Cveneba
                int achvene = Math.Min(gamocnobaThvla, 5);
                Console.Write("Sheni bolo gamocnobebi: ");
                for (int i = 0; i < achvene; i++)
                {
                    int idx = (gamocnobaThvla - achvene + i) % 5;
                    Console.Write(boloGamocnobebi[idx] + (i < achvene - 1 ? ", " : "\n"));
                }

                return;
            }

            // mimarTulebis minisTneba
            Console.WriteLine(gamocnoba < saidumloRicxvi ? "Metia ↑" : "Naklebia ↓");

            // siaxlovis ministneba MinistnebisMasivi masividan
            int manZili = Math.Abs(saidumloRicxvi - gamocnoba);
            int ministnebishIndex = manZili switch
            {
                <= 5 => 4, // dzaan axloaa
                <= 15 => 3, // axloaa
                <= 30 => 2, // cota axloaa
                <= 50 => 1, // shorstaa
                _ => 0  // dzaan shorstaa
            };
            Console.WriteLine($"Ministneba: {MinistnebisMasivi[ministnebishIndex]}");
        }
    }
}

// damxmare klasi - Seyvanis validacia
static class InputHelper
{
    // mteli ricxvis wakitxva mocemul diapazonshi
    public static int WaikitkheInt(string motxovna, int min, int max)
    {
        while (true)
        {
            Console.Write(motxovna);

            // TryParse + diapazonish Shemowmeba
            if (int.TryParse(Console.ReadLine(), out int mniSvneloba)
                && mniSvneloba >= min
                && mniSvneloba <= max)
            {
                return mniSvneloba;
            }

            Console.WriteLine($"Sheiyvanet ricxvi {min}-dan {max}-mde");
        }
    }

    // atobiti ricxvis wakitxva (InvariantCulture - wertili gamyofad)
    public static double WaikitkheDouble(string motxovna)
    {
        while (true)
        {
            Console.Write(motxovna);
            string Sheyvana = Console.ReadLine() ?? "";

            if (double.TryParse(
                    Sheyvana,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out double mniSvneloba))
            {
                return mniSvneloba;
            }

            Console.WriteLine("Aravalidi ricxvi.");
        }
    }

    // Enter-is molodini gagrdzelebamde
    public static void Daachere()
    {
        Console.WriteLine();
        Console.WriteLine("Gagrdzelebistvis daachire ENTER...");
        Console.ReadLine();
    }
}